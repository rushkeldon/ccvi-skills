#!/usr/bin/env python3
"""
modes.py — the fast path for the /modes skill.

Does everything the modes SKILL.md describes, deterministically, in one process:
- resolve the session id
- read the per-session active_modes.md
- parse a /modes directive
- compute the next state(s)
- write the file
- print a TWO-SECTION stdout: agent-facing notes, a delimiter, then the exact
  user-facing echo

The model's job around this script is trivial: run it, read the agent-notes above the
`===MODES_USER_ECHO===` delimiter and enforce them, print everything below the delimiter
verbatim, and only if the script fails (non-zero exit / no python / empty stdout) fall
back to the markdown logic in SKILL.md.

Contract:
  argv[1] = the raw directive — everything the user typed after "/modes", passed as a
            SINGLE quoted argument so the shell never glob-expands patterns like *.log.
            Examples: "plan ./doc", "exit sbs", "list", "clear", "exclude *.log, *.tmp",
            "" (blank -> help).

  stdout  = two sections split by delimiters:

              ===MODES_AGENT_NOTES===
              <private guidance for the agent — the behavioral contract for the modes
               active after this change; the agent internalizes and enforces it but
               NEVER displays it>
              ===MODES_USER_ECHO===
              <the exact echo-contract text, printed to the user verbatim>

  exit 0  = success (relay the user-echo section).
  exit !0 = failure (model falls back to SKILL.md logic). We print nothing to stdout on
            failure; any diagnostic goes to stderr.

Stdlib only. No third-party imports. Targets Python 3.9+ (the macOS Command Line Tools
system Python is frozen at 3.9.6; avoid 3.10+-only syntax).
"""

import os
import re
import sys
import glob


# --------------------------------------------------------------------------------------
# Delimiters — the dual-section contract. Blunt and collision-proof so the split
# instruction in SKILL.md is unambiguous and the agent-notes never leak to the user.
# --------------------------------------------------------------------------------------

AGENT_DELIM = "===MODES_AGENT_NOTES==="
ECHO_DELIM = "===MODES_USER_ECHO==="


# --------------------------------------------------------------------------------------
# Constants — the echo strings are load-bearing and mirror SKILL.md's contract; the
# golden tests assert byte-equality, so do not "improve" the wording or punctuation.
# --------------------------------------------------------------------------------------

DEFAULT_MODE = "agent"

# Simple (non-compound) modes and the mutually-exclusive stance group. plan / agent /
# agent-loop are a three-way mutex: entering any one displaces whichever sibling is
# active. agent-loop needs no MUTEX entry of its own — entering it clears EVERY other
# active mode (clear-on-entry subsumes the mutex).
SIMPLE_MODES = {"agent", "plan", "agent-loop", "one-word", "sbs", "exclude", "include"}
# Modes that render with a param. `agent-loop`'s is OPTIONAL — a bare `- agent-loop`
# entry (no threshold) is equally valid, so it renders compound only when one is stored.
COMPOUND_MODES = {"plan", "exclude", "include", "agent-loop"}

# agent-loop's optional rollover threshold: an integer percentage of context usage at
# which the session hands off to a fresh one. Floor 20 (below that a session rolls over
# before doing meaningful work), ceiling 99. Out-of-range is REFUSED, never clamped.
AGENT_LOOP_PCT_MIN = 20
AGENT_LOOP_PCT_MAX = 99
# agent-loop's named settings, after the optional threshold, in any order. timerDuration
# is the fallback wakeup in minutes (default 20; refused outside 20-60, never clamped).
# subagents carries a model (peer | economy) and a requirement (required | optional); the
# defaults (20, peer, required) are never stored, so a plain entry stays `agent-loop: 80`.
AGENT_LOOP_TIMER_MIN = 20
AGENT_LOOP_TIMER_MAX = 60
AGENT_LOOP_TIMER_DEFAULT = 20
SUBAGENT_MODELS = ("peer", "economy")
SUBAGENT_REQUIREMENTS = ("required", "optional")
MUTEX = {"plan": ("agent", "agent-loop"), "agent": ("plan", "agent-loop")}

# One-line blurb emitted with each enter echo. `plan` is a template: {dir} is the active
# plan directory, substituted at render time. The plan blurb reflects the softened rule
# (default to the dir, not confined to it).
PLAN_BLURB = ("new `*.plan.md` default to `{dir}` (default `./`), or elsewhere if you ask; "
              "create/edit/copy/move/rename any existing `.md` anywhere — only delete is "
              "forbidden; non-markdown writes blocked. Produce a `*.plan.md`")
BLURBS = {
    "agent": "full agency; the default working stance",
    "agent-loop": "the autonomous flywheel — dormant until work starts, then work in "
                  "flight and a wakeup armed at every landing; only the blocker "
                  "taxonomy stops forward motion",
    "one-word": "responses are a single word",
    "sbs": "step-by-step; one step then wait for 'done'",
    "exclude": "block writes matching listed patterns",
    "include": "only allow writes matching listed patterns",
}

HELP_TEXT = """Modes · v0.0.40:
• plan [dir] — new *.plan.md created in [dir] (default ./); edit/copy/move any existing .md anywhere; md-delete & non-md writes blocked; mutex with agent
• agent — full agency; mutex with plan
• agent-loop [pct] [timerDuration=N] [subagents=peer|economy[,optional]] — autonomous keep-moving loop; hand-off at pct% context (20-99); wakeup every N min (20-60, default 20); clears all modes on entry; mutex with plan/agent
• one-word — single-word responses
• sbs — step-by-step; one step then wait
• exclude <globs> — block writes matching globs
• include <globs> — only allow writes matching globs

Enter:      /modes <mode-name> [param]
Exit:       /modes exit <mode-name>
List:       /modes list
Clear all:  /modes clear
"""


# --------------------------------------------------------------------------------------
# State model
#
# The active modes are a dict mapping mode-name -> param (or None for simple modes).
# Insertion order does not matter — the echo always alphabetizes.
#   `exclude` / `include` -> a list of glob patterns.
#   `plan`                -> the directory string.
#   others                -> None.
# --------------------------------------------------------------------------------------


def project_slug(cwd):
    # Claude Code's project dir name: EVERY non-alphanumeric character becomes '-', so
    # C:\Users\x\proj -> C--Users-x-proj and /Users/x/proj -> -Users-x-proj. A Windows cwd
    # still yields a RELATIVE slug (the drive colon becomes '-'), which matters because an
    # absolute-looking slug makes os.path.join discard the home prefix.
    #
    # This replaces an older rule that mapped only '\\', ':' and '/'. Those agree with
    # Claude Code on paths made of alphanumerics and separators, and DISAGREE on anything
    # containing '.', '_' or a space: /Users/k/my_app resolved to -Users-k-my_app here while
    # the host and Claude Code both use -Users-k-my-app, so the Python and TypeScript sides
    # keyed two different directories for the same project. Mirrors enforce_modes.py.
    return re.sub(r"[^a-zA-Z0-9]", "-", cwd)


def memory_key_dir(cwd):
    """
    The directory Claude Code keys AUTO-MEMORY by: the repository's main checkout, with
    symlinks resolved. Transcripts are keyed per folder; auto-memory is not.

    Probed 2026-10-19 — a worktree added through a symlink to its main checkout put the
    session's memory dir under the main checkout's REALPATH while its transcript stayed
    under the worktree; a session in a symlinked plain clone put both under the target.
    So: realpath, then follow .git -> gitdir: -> commondir when .git is a FILE (a worktree).

    Pure stdlib, no git subprocess. Mirrors memoryKeyDir() in the host's
    sidecar/src/paths.ts; the two must agree or a seed written by this skill lands where
    the sidecar never reads. Every failure path returns the cwd unchanged.
    """
    try:
        key = os.path.realpath(cwd)
    except OSError:
        key = cwd
    try:
        dot_git = os.path.join(key, ".git")
        # A worktree's .git is a FILE; a normal clone's is a directory.
        if not os.path.isfile(dot_git):
            return key
        with open(dot_git, "r", encoding="utf-8") as fh:
            line = fh.read().strip()
        if not line.startswith("gitdir:"):
            return key
        git_dir = os.path.abspath(
            os.path.join(key, line[len("gitdir:"):].strip()))
        commondir_file = os.path.join(git_dir, "commondir")
        if os.path.isfile(commondir_file):
            with open(commondir_file, "r", encoding="utf-8") as fh:
                common_dir = os.path.abspath(
                    os.path.join(git_dir, fh.read().strip()))
        else:
            common_dir = git_dir
        # basename must be '.git'. A submodule's commondir lands under .git/modules/<name>,
        # so this guard makes submodules and any unexpected layout fall back rather than
        # inventing a root.
        if os.path.basename(common_dir) == ".git":
            return os.path.dirname(common_dir)
    except (OSError, ValueError, UnicodeDecodeError):
        pass
    return key


def resolve_memory_root():
    """
    Return (session_dir, sid) where session_dir is `<auto-memory>/<session_id>/`, or
    (None, None) if there is no resolvable session id — in which case
    we run in-context only and never touch the filesystem.

    Auto-memory root is `$HOME/.claude/projects/<slug>/memory`, where <slug> is
    project_slug(memory_key_dir(cwd)) — every non-alphanumeric character of the
    REPOSITORY's path becomes '-'. For robustness on reads, if the derived path has no
    session dir yet, we glob every project for the session id; that glob is also what
    lets a session already running before this change find its file at the old location.
    """
    sid = os.environ.get("CLAUDE_CODE_SESSION_ID")
    if not sid:
        return None, None

    home = os.path.expanduser("~")

    # Primary: derive the project slug from the cwd's REPOSITORY (its main checkout when
    # the cwd is a git worktree), which is what Claude Code keys auto-memory by. Keying by
    # the cwd itself put a worktree window's state somewhere the host never looked.
    cwd = os.getcwd()
    slug = project_slug(memory_key_dir(cwd))
    primary = os.path.join(home, ".claude", "projects", slug, "memory")
    session_dir = os.path.join(primary, sid)

    # If a session dir already exists under the primary slug, use it.
    if os.path.isdir(session_dir):
        return session_dir, sid

    # Read-robustness: the file may live under a different project slug (e.g. the skill
    # was invoked from a subdir). Session ids are globally unique, so a glob is safe.
    pattern = os.path.join(home, ".claude", "projects", "*", "memory", sid, "active_modes.md")
    matches = glob.glob(pattern)
    if len(matches) == 1:
        return os.path.dirname(matches[0]), sid

    # Nothing exists yet (first run) — create under the cwd-derived slug.
    return session_dir, sid


def normalize_mode_name(name):
    """
    Pre-2.0.0 normalization: `one word` (space) -> `one-word`; lowercase everything
    (so `SBS` -> `sbs`). Also folds `agent loop` (space) -> `agent-loop`, covering
    hand-edited state files and multi-word `exit` targets. Returns the canonical name.
    """
    n = name.strip().lower()
    if n == "one word":
        return "one-word"
    if n == "agent loop":
        return "agent-loop"
    return n


def read_state(session_dir):
    """
    Read active_modes.md into a dict {mode: param}. Absent file / no session -> default
    (`agent`). Applies pre-2.0.0 normalization on read.
    """
    if session_dir is None:
        return {DEFAULT_MODE: None}

    path = os.path.join(session_dir, "active_modes.md")
    if not os.path.isfile(path):
        return {DEFAULT_MODE: None}

    with open(path, "r", encoding="utf-8") as fh:
        lines = fh.read().splitlines()

    # The file is a markdown bullet list under a "# Active modes" header (see
    # render_state_file). We scan only the "- <name>[: <param>]" bullets and ignore
    # everything else (header, blanks), so a stray hand-edit to the file can't crash us.
    state = {}
    for line in lines:
        line = line.strip()
        if not line.startswith("- "):
            continue
        body = line[2:].strip()  # drop the "- " bullet marker
        # A compound mode carries a param after a colon ("plan: ./doc",
        # "exclude: *.log, *.tmp"); a simple mode is just its bare name.
        if ":" in body:
            name, param = body.split(":", 1)
            name = name.strip()
            param = param.strip()
        else:
            name, param = body, None

        name = normalize_mode_name(name)  # fold pre-2.0 spellings on read

        # Store the param in the shape each mode expects: a pattern LIST for
        # exclude/include, the dir STRING for plan, the threshold STRING (or None when
        # the entry is bare) for agent-loop, None for the simple modes.
        if name in ("exclude", "include"):
            patterns = [p.strip() for p in param.split(",")] if param else []
            state[name] = [p for p in patterns if p]  # drop empties
        elif name == "plan":
            state[name] = param if param else "./"
        elif name == "agent-loop":
            state[name] = param if param else None  # optional threshold; bare is valid
        else:
            state[name] = None

    # An empty or fully malformed file is equivalent to "no state" -> default agent mode.
    if not state:
        state = {DEFAULT_MODE: None}

    return state


def render_mode_entry(name, param):
    """Render a single mode as it appears in a list — with its param when compound.

    Shared by the user echo ("plan: ./doc", "exclude: *.log, *.tmp") and the on-disk state
    file, so this render and the parse in read_state stay mirror images of each other.
    """
    if name in ("exclude", "include"):
        patterns = param or []
        return "{}: {}".format(name, ", ".join(patterns))
    if name == "plan":
        return "plan: {}".format(param if param else "./")
    if name == "agent-loop" and param:
        return "agent-loop: {}".format(param)  # threshold set; bare falls through below
    return name  # simple mode -> just its name


def render_state_file(state):
    """Serialize the state dict back to active_modes.md text (alphabetized)."""
    out = ["# Active modes", ""]
    for name in sorted(state.keys()):
        out.append("- " + render_mode_entry(name, state[name]))
    return "\n".join(out) + "\n"


def write_state(session_dir, state):
    """Write the state file, creating the session dir if needed."""
    os.makedirs(session_dir, exist_ok=True)
    path = os.path.join(session_dir, "active_modes.md")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(render_state_file(state))


# --------------------------------------------------------------------------------------
# Echo rendering (the USER-facing section)
# --------------------------------------------------------------------------------------


def parse_agent_loop_param(text):
    """Parse an agent-loop param string into its settings dict, or raise ValueError.

    Accepts an optional leading threshold, then `timerDuration=N` and
    `subagents=<v>[,<v>]` in any order. Returns only the parts that were given:
    keys `pct`, `timer`, and `subagents` (a (model, requirement) pair, defaults filled)."""
    parts = {}
    tokens = (text or "").split()
    if tokens and "=" not in tokens[0]:
        pct = tokens.pop(0)
        if (not re.fullmatch(r"\d{1,3}", pct)
                or not (AGENT_LOOP_PCT_MIN <= int(pct) <= AGENT_LOOP_PCT_MAX)):
            raise ValueError("agent-loop threshold must be an integer {}-{}".format(
                AGENT_LOOP_PCT_MIN, AGENT_LOOP_PCT_MAX))
        parts["pct"] = int(pct)
    for tok in tokens:
        name, sep, value = tok.partition("=")
        if not sep:
            raise ValueError("agent-loop settings are name=value: {}".format(tok))
        if name == "timerDuration":
            if "timer" in parts:
                raise ValueError("agent-loop timerDuration given twice")
            if (not re.fullmatch(r"\d{1,3}", value)
                    or not (AGENT_LOOP_TIMER_MIN <= int(value) <= AGENT_LOOP_TIMER_MAX)):
                raise ValueError("agent-loop timerDuration must be an integer {}-{} (minutes)".format(
                    AGENT_LOOP_TIMER_MIN, AGENT_LOOP_TIMER_MAX))
            parts["timer"] = int(value)
        elif name == "subagents":
            if "subagents" in parts:
                raise ValueError("agent-loop subagents given twice")
            values = [v.strip() for v in value.split(",") if v.strip()]
            models = [v for v in values if v in SUBAGENT_MODELS]
            reqs = [v for v in values if v in SUBAGENT_REQUIREMENTS]
            unknown = [v for v in values if v not in SUBAGENT_MODELS + SUBAGENT_REQUIREMENTS]
            if not values or unknown or len(models) > 1 or len(reqs) > 1:
                raise ValueError("agent-loop subagents takes one of peer|economy and/or one of "
                                 "required|optional: {}".format(value))
            parts["subagents"] = (models[0] if models else "peer", reqs[0] if reqs else "required")
        else:
            raise ValueError("unknown agent-loop setting: {}".format(name))
    return parts


def render_agent_loop_param(parts):
    """Normalized param string for stored settings: threshold, then timerDuration, then
    subagents (model first), each omitted at its default. None when nothing is stored."""
    out = []
    if parts.get("pct") is not None:
        out.append(str(parts["pct"]))
    if parts.get("timer") not in (None, AGENT_LOOP_TIMER_DEFAULT):
        out.append("timerDuration={}".format(parts["timer"]))
    model, req = parts.get("subagents") or ("peer", "required")
    sub = [v for v in (model, req) if v not in ("peer", "required")]
    if sub:
        out.append("subagents=" + ",".join(sub))
    return " ".join(out) or None


def blurb_for(mode, param):
    """The one-line blurb for an enter echo. `plan` substitutes its active directory;
    `agent-loop` appends each stored setting (bare -> static blurb)."""
    if mode == "plan":
        return PLAN_BLURB.format(dir=(param if param else "./"))
    if mode == "agent-loop" and param:
        parts = parse_agent_loop_param(param)
        blurb = BLURBS["agent-loop"]
        if "pct" in parts:
            blurb += "; hand-off at {}% context usage".format(parts["pct"])
        if parts.get("timer"):
            blurb += "; wakeup every {} min".format(parts["timer"])
        if parts.get("subagents"):
            sub = [v for v in parts["subagents"] if v not in ("peer", "required")]
            blurb += "; sub-agents {}".format(",".join(sub))
        return blurb
    return BLURBS.get(mode, "")


def render_active_list(state):
    """The 'active modes :' block. Alphabetized, one ' • ' bullet per line, or inline none."""
    if not state:
        return "active modes : none"
    lines = ["active modes :"]
    for name in sorted(state.keys()):
        lines.append(" • " + render_mode_entry(name, state[name]))
    return "\n".join(lines)


def enter_echo(mode, param, new_state, displaced, already):
    """Build the enter echo — the exact user-facing text for a `/modes <mode>` directive.

    `already`   -> the mode was already in the set (re-entered): the shorter echo variant.
    `displaced` -> the LIST of modes this enter turned off (a mutex sibling, or every
                   cleared mode for agent-loop's clear-on-entry); one "is now inactive"
                   line per entry, in the order given — no lines when nothing displaced.
    Wording/punctuation here is byte-locked by the golden tests — don't tweak it.
    """
    blurb = blurb_for(mode, param)
    if already:
        return "mode {m} is already active.\nmode {m} : {b}\n{lst}".format(
            m=mode, b=blurb, lst=render_active_list(new_state))
    lines = ["mode {} is now active.".format(mode)]
    for d in (displaced or []):  # mutex displacement or agent-loop's clear-on-entry
        lines.append("mode {} is now inactive.".format(d))
    lines.append("mode {} : {}".format(mode, blurb))
    lines.append(render_active_list(new_state))
    return "\n".join(lines)


# --------------------------------------------------------------------------------------
# Agent-notes rendering (the PRIVATE section — the per-mode behavioral contract).
#
# These LAW strings are the FULL, first-order enforcement contract — NOT a paraphrase.
# Pre-4.1 the notes were a 4-line summary and the strong prose lived only in SKILL.md;
# the summary was too weak to carry across a directive-less gap, so the agent would drift
# (e.g. do a non-markdown write while plan mode was active). The fix: emit the real law
# here, on EVERY directive, VERBATIM to the text between the matching
# <!-- LAW:x -->/<!-- /LAW:x --> markers in SKILL.md. test_modes.py locks byte-equality
# so the script and the markdown can never drift. `{dir}`/`{pats}` substitute at render.
#
# The script is only bookkeeping — it never discharges enforcement; that is the agent's
# job every turn. The plugin ALSO ships a PreToolUse hook (hooks/enforce_modes.py)
# that mechanically blocks a violating Write/Edit, so compliance does not rely on the
# agent's memory.
# --------------------------------------------------------------------------------------

LAW = {
    "plan": (
        "⛔ PLAN MODE — a HARD write filter, in force on EVERY turn until you exit. "
        "Running the fast-path script does NOT discharge it; enforcement is yours every "
        "turn, script or not. BEFORE any Write or Edit, check the target file type:\n"
        "• new *.plan.md → default to `{dir}`; elsewhere only if the user explicitly asks "
        "(then do it, don't refuse)\n"
        "• edit / copy / move / rename any EXISTING .md → allowed anywhere; note the "
        "operation in one line as you do it\n"
        "• delete markdown → BLOCKED; archive (move) it instead and decline the delete "
        "plainly\n"
        "• any NON-markdown write (.py .json .ts .zip …) → BLOCKED; decline with "
        "\"can't — plan mode; only markdown writes allowed\", then offer to exit plan mode "
        "(/modes agent) if they want it done\n"
        "• Read / Glob / Grep / read-only Bash → unaffected\n"
        "• status reports → allowed: `agents_report.py put` and `status_report.py put` only, by name; no other write is excused\n"
        "If you are about to write a non-.md file you have already erred — refuse and "
        "surface it; never \"just this once\"."
    ),
    "agent": (
        "AGENT MODE — full agency, the default working stance. No plan-mode write filter; "
        "any other active modes (include / exclude / one-word / sbs) still bind. When your "
        "work is driven by a *.plan.md, open it in the host's plan editor by running the "
        "command the capability note in your system prompt teaches, with the plan's absolute "
        "path, as you take the plan up; a session with no capability note has nothing to run."
    ),
    "agent-loop": (
        "⛔ AGENT-LOOP MODE — a standing keep-moving contract, in force on EVERY turn until the user exits it. Running the fast-path script does NOT discharge it; enforcement is yours every turn, script or not. Entering the mode is DORMANT arming only — it starts no work, schedules no wakeup, spawns nothing; turns end normally while no work is assigned. The MOMENT work starts (you are told the work, or you begin work already known), the flywheel engages and these bind:\n"
        "• LAND WITH WORK IN FLIGHT AND A WAKEUP ARMED, or do not land. The binding check is at the LANDING: in flight means a RUNNING SUB-AGENT; a wakeup with nothing running is NOT compliance, and doing a unit yourself is compliance only while the turn lasts, never a state to land in. The one exception is an entry carrying `subagents=optional`: there a landing with the wakeup armed is compliant, and the wakeup is still mandatory.\n"
        "• arm FIRST on seeded and resumed turns — and on any woken turn — before any work, because a turn that dies before its first tool call leaves NOTHING armed. The wakeup is LONG (the entry's `timerDuration` minutes, 20 when unset), is insurance behind running work rather than a schedule, and carries this mode's own re-entry brief as its prompt, never a generic sentinel.\n"
        "• EVERY WAKE RE-ESTABLISHES THE INVARIANT FIRST — a returning worker spawns its successor; a wakeup firing with nothing in flight spawns before it does anything else.\n"
        "• DELEGATE BY DEFAULT, IN PARALLEL wherever independent units exist — one worker is the floor, not the target. gate exclusive resources: a resource only one worker can safely hold gets AT MOST ONE holder, and the next worker gets non-conflicting work rather than a queue position.\n"
        "• DECIDE, LOG, CONTINUE. Stop and ask ONLY for: contradicting the project's stated guidance with no compliant path; a compounding, hard-to-reverse fork the guidance cannot arbitrate; destructive actions; real-world money. Cost and effort forecasts are NEVER a reason to stop, shrink or ask — yours run in human-engineer units and are reliably wrong.\n"
        "• STATE WHAT MUST BE RESOLVED, AND THE CHECK THAT PROVES IT, BEFORE NAMING ANY TOOL. An unusable result restarts at that statement, never at a write-up — re-tooling produces nothing visible and is still the work.\n"
        "• REPORT TRUTHFULLY — \"nothing will wake me\" is a sentence to WRITE, never a state to conceal; a turn ending on a wait names what is running and what wakes it; a summary never promises work the turn did not do; and A NUMBER IS REPORTED WITH THE OUTPUT OF ITS CHECK BESIDE IT.\n"
        "• KEEP THE LIVE PLAN OR STATUS SURFACE TRUE IN REAL TIME — flip the unit to in_progress at the launch that commits to it, to completed only once its done-when is verified (a sub-agent's self-report is evidence, not the verdict; a work order handed to another session is verified by that session's isDone), to a truthful terminal state promptly on a bail. Every flip is the orchestrator's; a worker never touches it.\n"
        "• EVERY WORKER BRIEF DRAWS ITS FENCE — what it owns, and what it must never touch: the plan, the autonomy log, other units' files. It commits its own named pathspec or nothing at all — NEVER add-all, which sweeps racing siblings' edits into your commit.\n"
        "• rollover threshold — when the mode entry carries a percentage (`agent-loop: N`), N% context usage is the hand-off point: drain in-flight work first, spawn nothing new, author the seed, request the fresh session. Checked at every landing, because nothing else triggers it.\n"
        "• MECHANISM IS LOOKUP, NOT LAW — the autonomy-log path ladder, rollover detection, model economy, degradation on a host missing a capability, the cron prohibition, hand-off pacing and plan surfacing all live in the skill body. Read that section once when the flywheel first engages.\n"
        "If work remains and you are about to end a turn without work in flight and a wakeup armed, you have already erred — spawn and arm before you land; never land idle (the drained rollover hand-off is the one sanctioned landing: the invariant passes to the successor session)."
    ),
    "one-word": (
        "ONE-WORD MODE — every response is exactly one word, on every turn until you exit. "
        "Apply literally: no punctuation flourishes, no trailing clause."
    ),
    "sbs": (
        "SBS MODE — do exactly ONE step, then STOP and wait for the user to say 'done' "
        "before the next. Never chain steps. Binds every turn until you exit."
    ),
    "exclude": (
        "⛔ EXCLUDE MODE — refuse any Write or Edit whose target matches: {pats}. Binds "
        "every turn until you exit. Name the matched pattern when you decline. "
        "Read / Glob / Grep are unaffected."
    ),
    "include": (
        "⛔ INCLUDE MODE — refuse any Write or Edit whose target does NOT match one of: "
        "{pats}. Binds every turn until you exit. Say the file isn't in the include set "
        "when you decline. Read / Glob / Grep are unaffected."
    ),
}


def mode_note(name, param):
    """The canonical enforcement law for one active mode, with its param substituted in.

    Returns LAW[name] verbatim (byte-locked to SKILL.md) with the `{dir}`/`{pats}` token
    filled. We use str.replace, NOT str.format: the law prose contains other literal
    braces/punctuation that would trip format(), whereas replace only touches our token.
    """
    text = LAW.get(name, "")
    if name == "plan":
        text = text.replace("{dir}", param if param else "./")
    elif name in ("exclude", "include"):
        text = text.replace("{pats}", ", ".join(param or []))
    return text


# The generative closer. The LAW above is a DECLARATION — passively read, and it fades by
# the next unrelated turn. This turns the moment into an ASK: a short predict-then-derive
# exercise the agent must actually ANSWER (generate tokens for) in its private reasoning
# before it replies. The point is the generation effect: a contract you DERIVE for yourself
# encodes and binds all session; one you are merely told does not. We deliberately spend a
# few tokens here to buy session-long adherence — this is the one thing the fast script
# gave up when it took over the bookkeeping the agent used to reason through by hand.
#
# Kept OUT of the per-mode LAW blocks (it is generic, not mode-specific) and off the
# empty/clear state (nothing to encode once no mode is active). Not byte-locked to SKILL.md
# the way LAW is — it is a generative prompt, not a contract whose wording tests pin.
ENCODE_PROMPT = (
    "Now ENCODE this; do not just read it. The script did the bookkeeping, but building the "
    "understanding is yours — and a contract you DERIVE sticks where one you are handed "
    "fades. Before you emit the echo, work these out in your own reasoning (never shown to "
    "the user), actually writing a sentence for each — do not answer them only in your head:\n"
    "  1. Predict what active_modes.md now holds, then verify it against the echo below.\n"
    "  2. Name one concrete thing you will do differently many turns from now, when no "
    "script has run and nothing is reminding you.\n"
    "  3. State the single event, and nothing short of it, that ends this obligation.\n"
    "If you jumped straight to the echo without answering, you have not encoded it: stop and "
    "answer now, then carry on. This mode is not a message that fades; it is a standing "
    "contract you just derived."
)

# The agent-loop-specific ask, appended to ENCODE_PROMPT when that mode is active.
# WHY IT EXISTS: the law block was cut by ~60% on the argument that repetition and
# derivation are substitutes — the long block stuck because it was re-read on every wake,
# and a shorter one has to buy that back by being DERIVED instead. Shipping the cut without
# the derivation would leave the mode binding LESS than before, which is a regression, not a
# tidy-up. This is the other half of that trade.
# WHY THIS SHAPE: it is ONE question and it is FALSIFIABLE — a prediction about a specific
# future moment (this turn's landing) that reality settles a few minutes later. The generic
# asks above include two with no checkable answer, and a reflective prompt answered many
# times becomes recital; recital does not encode.
ENCODE_AGENT_LOOP = (
    "  4. AGENT-LOOP — predict now, in one sentence, what THIS TURN'S LANDING must contain: "
    "what will be running, and what will be armed. Check that prediction against what you "
    "actually land with. If they differ you have not complied — fix it before you land, and "
    "do not describe the difference away."
)


def render_agent_notes(state):
    """The private agent-notes block (above the echo delimiter) for the post-change modes.

    One law paragraph per active mode (alphabetized for stable output), then the generative
    ENCODE_PROMPT that makes the agent DERIVE the "standing until revoked" conclusion rather
    than be told it. Empty state is the `/modes clear` case -> a single "no modes" line (no
    ask: nothing is active to encode).
    """
    if not state:
        return "No modes active — full default agency."
    parts = [mode_note(n, state[n]) for n in sorted(state.keys())]
    ask = ENCODE_PROMPT
    if "agent-loop" in state:
        # Insert the mode-specific falsifiable ask BEFORE the closing exhortation, so it
        # reads as item 4 of the list rather than as an afterthought below the sign-off.
        marker = "If you jumped straight to the echo"
        ask = ask.replace(marker, ENCODE_AGENT_LOOP + "\n" + marker, 1)
    parts.append(ask)
    return "\n".join(parts)


# --------------------------------------------------------------------------------------
# Directive parsing + dispatch
# --------------------------------------------------------------------------------------


def parse_directive(raw):
    """
    Split the raw directive into (verb, rest). verb is lowercased; rest is the remainder.
    Blank -> ('', '').
    """
    raw = (raw or "").strip()
    if not raw:
        return "", ""
    parts = raw.split(None, 1)
    verb = parts[0].lower()
    rest = parts[1].strip() if len(parts) > 1 else ""
    return verb, rest


def split_patterns(rest):
    """Comma-split a pattern param, trim, drop empties."""
    return [p.strip() for p in rest.split(",") if p.strip()]


def apply_directive(state, raw):
    """
    Compute (new_state, echo_text, should_write, agent_notes) for the directive.

    Raises ValueError for a directive we cannot handle (caller turns that into a
    non-zero exit -> fallback). should_write is False for read-only verbs (list, help);
    agent_notes is '' for the cheat-sheet (no active-mode change to reinforce).
    """
    verb, rest = parse_directive(raw)

    # Blank / unknown verb -> help cheat sheet (read-only: no notes, no write).
    if verb == "":
        return state, HELP_TEXT, False, ""

    # list: report the CURRENT modes. should_write=False (read-only), but notes ARE emitted
    # so a plain `/modes list` still re-reminds the agent of the active contract.
    if verb == "list":
        return state, render_active_list(state), False, render_agent_notes(state)

    # clear: drop every mode -> empty state (== defaults); writes the emptied file.
    if verb == "clear":
        return {}, "all modes cleared.\nactive modes : none", True, render_agent_notes({})

    if verb == "exit":
        if not rest:
            raise ValueError("exit needs a mode name")
        # Normalize the WHOLE rest first so a two-word target ("exit agent loop")
        # resolves to agent-loop instead of silently exiting bare `agent`; fall back
        # to the first token for the normal single-word targets.
        whole = normalize_mode_name(rest)
        target = whole if whole in SIMPLE_MODES else normalize_mode_name(rest.split(None, 1)[0])
        new_state, echo, should_write = apply_exit(state, target)
        return new_state, echo, should_write, render_agent_notes(new_state)

    # Two-word-verb guard: "/modes agent loop" parses as verb `agent`, rest `loop`,
    # and would otherwise silently enter plain agent mode. A threshold may trail it
    # ("agent loop 20"), so keep whatever follows `loop` as the param.
    if verb == "agent":
        tail = rest.split(None, 1)
        if tail and tail[0].lower() == "loop":
            verb, rest = "agent-loop", (tail[1].strip() if len(tail) > 1 else "")

    mode = normalize_mode_name(verb)
    if mode not in SIMPLE_MODES:
        # Unrecognized verb -> help (matches "blank or unrecognized verb -> Help output").
        return state, HELP_TEXT, False, ""

    new_state, echo, should_write = apply_enter(state, mode, rest)
    return new_state, echo, should_write, render_agent_notes(new_state)


def apply_enter(state, mode, rest):
    """Enter `mode` and return (new_state, echo, should_write=True).

    Three shapes: compound (exclude/include — APPEND + dedupe patterns), plan (stores its
    dir, displaces agent via the mutex), and the simple modes. Operates on a copy so the
    caller's state is never mutated in place.
    """
    new_state = dict(state)

    # Compound modes: exclude / include APPEND the given patterns to any existing set
    # (deduped) rather than replacing it — so successive directives build the set up.
    if mode in ("exclude", "include"):
        patterns = split_patterns(rest)
        already = mode in new_state
        if not patterns and not already:
            # Empty pattern args, mode not yet active -> no-op ask (routed to the model
            # via a non-zero exit / fallback). Draft decision: fallback-to-ask.
            raise ValueError("empty pattern args")
        existing = list(new_state.get(mode, []))
        added = [p for p in patterns if p not in existing]  # only genuinely new patterns
        new_state[mode] = existing + added
        # Patterns actually added -> "now active" with the updated set; nothing new
        # (re-invoke with all-existing patterns, or empty on an active set) -> "already".
        already_echo = not added
        return new_state, enter_echo(mode, new_state[mode], new_state, None, already_echo), True

    if mode == "plan":
        param = rest.strip() if rest.strip() else "./"  # no dir given -> default ./
        already = "plan" in new_state
        # plan / agent / agent-loop are mutually exclusive: entering plan turns the
        # active sibling off, and each displacement is named in the echo.
        displaced = []
        for sib in MUTEX.get("plan", ()):
            if sib in new_state:
                del new_state[sib]
                displaced.append(sib)
        new_state["plan"] = param
        return new_state, enter_echo("plan", param, new_state, displaced, already), True

    # agent-loop: the sole-operant stance — entering it clears EVERY other active mode,
    # not just the mutex siblings. Re-entry is idempotent: layered modes survive. The
    # optional param is the rollover threshold (a percentage of context usage); re-entry
    # semantics mirror exclude — a NEW value updates ("now active"), a bare or identical
    # re-entry preserves what's stored ("already active") and never erases it.
    if mode == "agent-loop":
        # Any invalid part -> ValueError -> ask, don't clamp and don't write (same
        # fallback-to-ask treatment as empty pattern args).
        given = parse_agent_loop_param(rest)
        already = "agent-loop" in new_state
        if already:
            stored = new_state.get("agent-loop")
            merged = parse_agent_loop_param(stored)
            merged.update(given)  # a given setting replaces only that setting
            param = render_agent_loop_param(merged)
            if not given or param == stored:
                # bare or same-settings re-entry: idempotent, stored settings preserved
                return new_state, enter_echo("agent-loop", stored, new_state, [], True), True
            new_state["agent-loop"] = param  # changed settings: update in place, layered modes survive
            return new_state, enter_echo("agent-loop", param, new_state, [], False), True
        param = render_agent_loop_param(given)
        displaced = sorted(new_state.keys())
        new_state = {"agent-loop": param}
        return new_state, enter_echo("agent-loop", param, new_state, displaced, False), True

    # Simple modes (agent, one-word, sbs). agent is a member of the three-way stance
    # mutex, handled generically through the MUTEX table below.
    already = mode in new_state
    displaced = []
    for sib in MUTEX.get(mode, ()):
        if sib in new_state:  # displace each active mutex sibling
            del new_state[sib]
            displaced.append(sib)
    new_state[mode] = None
    return new_state, enter_echo(mode, None, new_state, displaced, already), True


def apply_exit(state, target):
    """Exit `target` and return (new_state, echo, should_write=True).

    Deleting the key drops the mode entirely — for exclude/include that clears the WHOLE
    pattern set (there is no per-pattern removal). Exiting a mode that isn't active is not
    an error: it emits the "is not active" echo and still rewrites the file, so the on-disk
    state is always reasserted.
    """
    new_state = dict(state)
    if target in new_state:
        del new_state[target]
        echo = "mode {} is now inactive.\n{}".format(target, render_active_list(new_state))
        return new_state, echo, True
    echo = "mode {} is not active.\n{}".format(target, render_active_list(new_state))
    return new_state, echo, True


# --------------------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------------------


def main(argv):
    raw = argv[1] if len(argv) > 1 else ""  # the raw directive, or "" -> help

    # 1-2. locate this session's state file, then read current modes (default agent if none).
    session_dir, _sid = resolve_memory_root()
    state = read_state(session_dir)

    # 3. compute the resulting state + the two output sections for this directive.
    new_state, echo, should_write, notes = apply_directive(state, raw)

    # 4. Assemble the dual-section stdout: AGENT_DELIM, [agent-notes], ECHO_DELIM, echo. The
    # notes line is omitted for the cheat-sheet (notes == ""), leaving an empty agent
    # section; the trailing newline keeps the echo a clean final line for the caller.
    # Built BEFORE the state write so nothing after the write can fail on formatting.
    out = [AGENT_DELIM]
    if notes:
        out.append(notes)
    out.append(ECHO_DELIM)
    out.append(echo)
    text = "\n".join(out) + "\n"

    # 5. Persist state for state-mutating verbs when a session dir is resolvable. Read-only
    # verbs (list, help) never write; no-session surfaces run in-context only.
    if should_write and session_dir is not None:
        write_state(session_dir, new_state)

    # 6. Emit.
    emit(text)
    return 0


def emit(text):
    # Explicit UTF-8: Windows Python writes piped stdout as cp1252, which cannot encode the
    # LAW blocks' ⛔. Bytes bypass the platform default; on macOS/Linux they are what
    # sys.stdout already produced.
    data = text.encode("utf-8")
    buf = getattr(sys.stdout, "buffer", None)
    if buf is not None:
        buf.write(data)
        buf.flush()
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv))
    except Exception as exc:  # any failure -> non-zero exit -> model falls back
        sys.stderr.write("modes.py error: {}\n".format(exc))
        sys.exit(1)
